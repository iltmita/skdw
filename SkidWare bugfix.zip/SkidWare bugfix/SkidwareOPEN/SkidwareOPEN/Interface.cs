﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using ForlornApi;

namespace SkidwareOPEN
{
    public partial class Interface : Form
    {
        public Interface()
        {
            InitializeComponent();
            colorTimer.Tick += OnColorTimerTick;
            colorTimer.Start();
        }
        private int red = 255;
        private int green = 0;
        private int blue = 0;
        private int colorChangeStep = 15;
        private void OnColorTimerTick(object sender, EventArgs e)
        {
            // Изменение цветов по кругу
            if (red == 255 && green < 255 && blue == 0)
            {
                green += colorChangeStep;
            }
            else if (green == 255 && red > 0 && blue == 0)
            {
                red -= colorChangeStep;
            }
            else if (green == 255 && blue < 255)
            {
                blue += colorChangeStep;
            }
            else if (blue == 255 && green > 0)
            {
                green -= colorChangeStep;
            }
            else if (blue == 255 && red < 255)
            {
                red += colorChangeStep;
            }
            else if (red == 255 && blue > 0)
            {
                blue -= colorChangeStep;
            }

            // Установка нового цвета панели
            RGB_Panel.BackColor = Color.FromArgb(red, green, blue);
        }
        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Fetch.PopulateListBox(listBox1, "./scripts", "*.txt");
            Fetch.PopulateListBox(listBox1, "./scripts", "*.lua");
            this.TopMost = true;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            scriptBox.Text = File.ReadAllText($"./scripts/{listBox1.SelectedItem}");
        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                openFileDialog1.Title = "Open";
                scriptBox.Text = File.ReadAllText(openFileDialog1.FileName);
            }
        }

        private void siticoneButton6_Click(object sender, EventArgs e)
        {
            ScriptForm scripthub = new ScriptForm();
            scripthub.ShowDialog();
        }

        private void siticoneButton7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Fetch.PopulateListBox(listBox1, "./scripts", "*.txt");
            Fetch.PopulateListBox(listBox1, "./scripts", "*.lua");
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            Api.Inject();
            if (Api.IsInjected() == true) {
                MessageBox.Show("Injeckted", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            Api.ExecuteScript(scriptBox.Text);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (this.TopMost == true) {
                label2.ForeColor = Color.DarkRed;
                this.TopMost = false;
            }
            else if (this.TopMost == false) {
                label2.ForeColor = Color.Green;
                this.TopMost = true;
            }
        }
    }
}
