﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ForlornApi;

namespace SkidwareOPEN
{
    public partial class ScriptForm : Form
    {
        public ScriptForm()
        {
            InitializeComponent();
        }

        private void siticoneButton6_Click(object sender, EventArgs e)
        {
            // Сделал по сложному, можно легче (пример) : Api.ExecuteScript($"loadstring(game:HttpGet(\"https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/latest.lua\"))()");
            // Зато текущий способ универсальнее
            string scriptLink = "https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/latest.lua";
            Api.ExecuteScript($"loadstring(game:HttpGet(\"{scriptLink}\"))()");
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            string scriptLink = "https://raw.githubusercontent.com/unified-naming-convention/NamingStandard/main/UNCCheckEnv.lua";
            Api.ExecuteScript($"loadstring(game:HttpGet(\"{scriptLink}\"))()");
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            string scriptLink = "https://gitlab.com/sens3/nebunu/-/raw/main/HummingBird8's_sUNC_yes_i_moved_to_gitlab_because_my_github_acc_got_brickedd/sUNCm0m3n7.lua";
            Api.ExecuteScript($"loadstring(game:HttpGet(\"{scriptLink}\"))()");
        }

        private void siticoneButton5_Click(object sender, EventArgs e)
        {
            string scriptLink = "https://pastebin.com/raw/qJPqEtMn";
            Api.ExecuteScript($"loadstring(game:HttpGet(\"{scriptLink}\"))()");
        }

        private void siticoneButton7_Click(object sender, EventArgs e)
        {
            string scriptLink = "https://raw.githubusercontent.com/Incoak/lua/main/toh";
            Api.ExecuteScript($"loadstring(game:HttpGet(\"{scriptLink}\"))()");
        }

        private void siticoneButton8_Click(object sender, EventArgs e)
        {
            // Скоро будет гайд, по тому как создать свой простой скрипт
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }
    }
}
